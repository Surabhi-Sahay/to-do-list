## Follow Below Instructions:

First get this starter code repo by just writing below command ni command prompt or terminal.

#### git clone --single-branch --branch starter-code https://github.com/codebucks27/React-Todo-app.git

After that do,


### `npm install`

and 

### `npm start`

You can Follow This Tutorial to build whole App.
https://youtu.be/9zcMnJI3B7M


This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).
